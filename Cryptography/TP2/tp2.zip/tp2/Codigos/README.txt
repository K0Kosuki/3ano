O código desenvolvido está comentado no relatorio. tp2.pdf

Na pasta 'Tp2 final',no 'main',enviar uma lista de opções de comunicação com os diferentes tipos de garantia de segurança suportadas