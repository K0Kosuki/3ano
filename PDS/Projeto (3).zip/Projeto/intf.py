import tkinter as tk
from tkinter import messagebox
import pyaudio
import wave
import scipy.io.wavfile as wavfile
import python_speech_features as sf
import joblib

# 录音配置
FRAMES_PER_BUFFER = 3200
FORMAT = pyaudio.paInt16
CHANNELS = 1
RATE = 16000
RECORD_SECONDS = 1.7
WAVE_OUTPUT_FILENAME = "test.wav"  # 修改为您的路径

# 录音功能
def record_audio():
    pa = pyaudio.PyAudio()
    stream = pa.open(format=FORMAT, channels=CHANNELS, rate=RATE, input=True, frames_per_buffer=FRAMES_PER_BUFFER)

    messagebox.showinfo("Recording", "开始录音...")
    frames = []

    for i in range(0, int(RATE / FRAMES_PER_BUFFER * RECORD_SECONDS)):
        data = stream.read(FRAMES_PER_BUFFER)
        frames.append(data)

    stream.stop_stream()
    stream.close()
    pa.terminate()

    wave_file = wave.open(WAVE_OUTPUT_FILENAME, 'wb')
    wave_file.setnchannels(CHANNELS)
    wave_file.setsampwidth(pa.get_sample_size(FORMAT))
    wave_file.setframerate(RATE)
    wave_file.writeframes(b''.join(frames))
    wave_file.close()

    messagebox.showinfo("Recording", "录音完成")

# 退出程序
def on_exit():
    if messagebox.askokcancel("Quit", "确定要退出程序吗？"):
        root.destroy()

# 创建GUI
root = tk.Tk()
root.title("录音控制界面")

start_button = tk.Button(root, text="开始录音", command=record_audio)
start_button.pack(pady=10)

exit_button = tk.Button(root, text="退出", command=on_exit)
exit_button.pack(pady=10)

root.protocol("WM_DELETE_WINDOW", on_exit)
root.mainloop()
