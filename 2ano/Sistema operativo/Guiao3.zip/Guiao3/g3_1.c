// Isto está errado!!!!!

#include <stdio.h>
#include <unistd.h>

int main(int argc, char* argv[]){
	printf("Antes\n");

	execlp("ls", "ls", NULL);

	printf("Depois\n");
}
int pid;
if(!(pid = fork())){
	
}


for(i = 1; i <= argc; i++){
	wait(&status);

	if(WIFEXITED(status)){

	}else{
		
	}

}

