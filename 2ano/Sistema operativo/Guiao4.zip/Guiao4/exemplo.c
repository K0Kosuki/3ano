#include <unistd.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>

int main(){

	int f;

	close(1);

	f = open("./lix2", O_WRONLY, O_CREAT, O_TRUNC, 0600);

	if(f==-1){
		perror("erro no open");
		exit(-1);
	}

	write(f, "Ola PL3\n", 8);

	if(f==-1){
		perror("erro no open");
		exit(-1);
	}
}
