#include <unistd.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>

int main(){

	int f;

	f = open("erros.txt", O_WRONLY | O_CREAT | O_APPEND, 0600);
	dup2(f, 2);
	close(f);

	f = open("/etc/passwdddddddd", O_RDONLY);
	if(f == -1){perror("passwd");}
	dup2(f, 0);
	close(f);

/*	close(0);
	dup(f);
	close(f);
*/
	f = open("saida.txt", O_WRONLY | O_CREAT | O_TRUNC, 0600);
	dup2(f, 1);
	close(f);

	if(!fork()){
		// exclp wc wc
	}
}
