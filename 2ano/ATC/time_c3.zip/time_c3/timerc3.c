#include<c8051f380.h>

    void main()
{

    PCA0MD = 0x00;
    XBR1 = 0x40;

    while (1)
    {

        if (P0_6 == 0)
        {                                 
            P2 = 0xb0;
			                     //display 3
        }
        else if (P0_7 == 0 )    
        {
            P2 = 0xFF;        //off
        }
    }
}
