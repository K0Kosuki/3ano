public class Liquidas extends Carga{


    public Liquidas() {
        super.setCodigo( 1234);
    }


    @Override
    public boolean equals(Object obj) {
        return super.equals(obj);
    }
    @Override
    protected Object clone() throws CloneNotSupportedException {
        return super.clone();
    }
    @Override
    public String toString() {
        return super.toString();
    }
    @Override
    public double consumo() {
        return 0;
    }
    @Override
    public double preco() {
        return 0;
    }
}
