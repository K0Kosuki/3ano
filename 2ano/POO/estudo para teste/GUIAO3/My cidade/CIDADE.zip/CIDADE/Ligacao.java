
public class Ligacao
{
    private Cidade origem;
    private Cidade destino;
    private double distancia;
    
    public Ligacao(Cidade o,Cidade d)
    {
        this.origem=o;
        this.destino = d;
      
    }
    public Cidade getOrigem()
    {
        return this.origem;
    }
    public Cidade getDestino()
    {
        return this.destino;
    }
    
    
}
