import java.util.ArrayList;
public class Cidade
{
    // variáveis de instância - substitua o exemplo abaixo pelo seu próprio
    private String nome;
   
   ;

    public Cidade(String nom)
    {
      this.nome = nom;
    }
    
    public String getNomeC()
    {
        return this.nome;
    }
   
    
   
}
