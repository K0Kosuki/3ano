import java.util.ArrayList;
import java.util.*;

public class Mapa
{
    
    private String nomeP;
    private ArrayList<Cidade> lista_cidade;
    private ArrayList<Ligacao> lista_liga;
   

    /**
     * Construtor para objetos da classe Mapa
     */
    public Mapa(String n)
    {
        this.nomeP=n;
        this.lista_cidade= new ArrayList<Cidade>();
        this.lista_liga= new ArrayList<Ligacao>();
    }

    public String getNomeP()
    {
        return this.nomeP;
    }
    
    public void add(String nomeC)
    {
        this.lista_cidade.add(new Cidade(nomeC));
    }
    
    public void add(Cidade ori,Cidade des)
    {
        this.lista_liga.add(new Ligacao(ori,des));
    }
    
    public boolean exiteCaminho(Cidade ori,Cidade des)
    {
        for(Ligacao l:this.lista_liga)
        {
            if(l.getOrigem()==ori && l.getDestino()==des)
            return true;
            if(l.getOrigem()==des && l.getDestino()==ori)
            return true;
        }
        return false;
        }
    
    /*public Cidade getMax(Cidade ori,Cidade des)
    {
     int Conta_cidade =0;
     int cMax=-1;
     int cMaxI=-1;
     for(int i=0; i<this.lista_liga.size(); i++)
    {
        int count=0;
        for(Ligacao l: this.lista_liga)
        {
           if(this.lista_cidade[i] == l.getOrigem())
             Conta_cidade=count+1;
        }
        
        if(count>cMax)
        {
            cMax=count;
            cMaxI=i;
        }
        
    }
        
        return this.lista_cidade[cMaxI];
    }       */
}
    

