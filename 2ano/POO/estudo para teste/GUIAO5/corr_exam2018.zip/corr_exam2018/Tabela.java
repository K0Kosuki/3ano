
/**
 * Exemplo do que podia ser a classe Tabela com uma tabela de preços!
 * É apenas um exemplo. Podia ter muitas implementações diferentes.
 * Está aqui apenas para ser possível "compilar" o programa todo!
 */
public class Tabela
{
    private static double[] tabela = {12.2, 15.0, 16.0, 11.5, 23.4};
    
    public static double precos(int componente)
    {
       return tabela[componente]; 
    }
}
