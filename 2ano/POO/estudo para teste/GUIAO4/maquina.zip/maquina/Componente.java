
public interface Componente
  {      
    public double custo();
    public int getCod(); // devolve o código do componente!
  }

