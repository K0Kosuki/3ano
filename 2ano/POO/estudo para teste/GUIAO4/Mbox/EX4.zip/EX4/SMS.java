import java.util.*;
import java.util.ArrayList;
public class SMS extends Chamada
{
 private String texto;
 private ArrayList<Chamada> lista;
 private int n =0;
 
 public SMS(int ori,int cara,double preco,String tex)
 {
     super(ori,cara,preco);
     this.n +=1;
     ArrayList<Chamada> lista = new ArrayList<Chamada>();
     this.texto = tex;
 }
 
 public void add(Chamada c) 
 {
     this.lista.add(c);
 }
 
 public Chamada find(int ori)
 {
     Chamada contar =null;
     Iterator<Chamada> i = new this.lista.iterator();
     boolean ha= false;
     while(i.hasNext() && !ha)
     {
         contar = i.next();
         if(contar.getOrigem ==ori)
         {
             ha = true;
         }
     }
     if(ha)
     {
         return contar;
     }
     else
     return null;
 }
 
 
 public double valor(int ori)
 {
     Chamada c = this.find(ori);
     int n_caracter =0;
     if(c !=null)
     {
         n_caracter = c.getDuracao.length();
         return n_caracter*0.001;
     }
     else
     return false;
     
     
 }
 
 public SMS clone()
    {
        return new Voz(super.getOrigem(),super.getDuracao(),super.getPreco());
    }
 
 
}
