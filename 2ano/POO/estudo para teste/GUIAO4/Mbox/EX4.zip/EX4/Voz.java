
public class Voz extends Chamada
{
    
    public Voz(int ori,int dura,double preco)
    {
        super(ori,dura,preco);
    }
    
    public double valor()
    {
       return (super.getDuracao()*super.getPreco())/60;
    }
    
    public double happy()
    {
        return super.getDuracao()*0.1;
    }
    
    public Voz clone()
    {
        return new Voz(super.getOrigem(),super.getDuracao(),super.getPreco());
    }
}
